export const GalleryObject = [
    {
        'id': 'OQyRttOV4l8',
        'user_name': 'Gina Smith',
        'user_url': 'https://unsplash.com/@ginasmithphotography?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit',
        'photo_url': 'https://unsplash.com/photos/OQyRttOV4l8?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit'
    },
    {
        'id': '5XP-n_Xqqv8',
        'user_name': 'Jie Wang',
        'user_url': 'https://unsplash.com/@itworkonline?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit',
        'photo_url': 'https://unsplash.com/photos/5XP-n_Xqqv8?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit'
    },
    {
        'id': 'Shf_B7x8gDA',
        'user_name': 'Emmalee Couturier',
        'user_url': 'https://unsplash.com/@emmcout?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit',
        'photo_url': 'https://unsplash.com/photos/Shf_B7x8gDA?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit'
    },
    {
        'id': 'lFAhbzmvpak',
        'user_name': 'Kristaps Ungurs',
        'user_url': 'https://unsplash.com/@kristapsungurs?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit',
        'photo_url': 'https://unsplash.com/photos/lFAhbzmvpak?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit'
    },
    {
        'id': 'eFXho78pQH8',
        'user_name': 'Deniz Demirci',
        'user_url': 'https://unsplash.com/@ddography?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit',
        'photo_url': 'https://unsplash.com/photos/eFXho78pQH8?utm_source=unsample&utm_medium=referral&utm_campaign=api-credit'
    }
]